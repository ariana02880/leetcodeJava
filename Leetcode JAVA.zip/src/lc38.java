//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.Set;
// // Definition for singly-linked list.
//class ListNode {
//      int val;
//      ListNode next;
//     ListNode(int x) { val = x; }
//}
// //Definition for a binary tree node.
//class TreeNode {
//     int val;
//     TreeNode left;
//     TreeNode right;
//     TreeNode(int x) { val = x; }
// }
//
//class Solution {
//	//my
//	public String countAndSay2(int n) {
//        if (n <= 0) 
//			return "";
//        String ans="1";
//        while(--n>0){
//            String cur="";
//            for(int i=0;i<ans.length();i++){
//                Integer cnt=1;
//                while(i+1<ans.length()&& ans.charAt(i+1)==ans.charAt(i)){
//                    cnt++;
//                    i++;
//                }
//                cur+=cnt.toString()+ans.charAt(i); 
//            }
//            ans=cur;
//        }
//        return ans;
//    }
//}
//
//
//public class lc38 {
//	public static void main(String arg[]) {
//		Solution test=new Solution();
//		
//		//int[] a=test.plusOne(digits);
//		System.out.println("Hello World");
//
//	}
//}