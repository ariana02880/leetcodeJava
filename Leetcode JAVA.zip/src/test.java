//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Set;
//
// // Definition for singly-linked list.
//class ListNode {
//      int val;
//      ListNode next;
//     ListNode(int x) { val = x; }
//}
// //Definition for a binary tree node.
//class TreeNode {
//     int val;
//     TreeNode left;
//     TreeNode right;
//     TreeNode(int x) { val = x; }
// }
//
////class Solution {
////	public string licenseKeyFormatting(string S, int K) {
////		
////	}
////}
//
//
//public class test {
//	public static void main(String arg[]) {
//		String a = "A", b = "B", c = "C", d = "D", e = "E";
//		List<String> list = new LinkedList<String>();
//		list.add(a);
//		list.add(e);
//		list.add(d);
//		list.set(1, b);// ������λ��Ϊ1�Ķ���e�޸�Ϊ����b
//		list.add(2, c);// ������c���ӵ�����λ��Ϊ2��λ��
//		Iterator<String> it = list.iterator();
//		while (it.hasNext()) {
//			System.out.println(it.next());
//		}
//		
//		
//		System.out.println("Hello World");
//
//	}
//}