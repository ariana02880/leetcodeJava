//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.Set;
// // Definition for singly-linked list.
//class ListNode {
//      int val;
//      ListNode next;
//     ListNode(int x) { val = x; }
//}
// //Definition for a binary tree node.
//class TreeNode {
//     int val;
//     TreeNode left;
//     TreeNode right;
//     TreeNode(int x) { val = x; }
// }
//
//class Solution {
//	public int lengthOfLastWord(String s) {
//        if(s.length()<=0)
//            return 0;
//        String [] temp=s.split(" ");
//        if(temp.length==0)
//            return 0;
//        return temp[temp.length-1].length();
//    }
//}
//
//
//public class lc58 {
//	public static void main(String arg[]) {
//		Solution test=new Solution();
//		
//		int[] a=test.plusOne(digits);
//		System.out.println("Hello World");
//
//	}
//}