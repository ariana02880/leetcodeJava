//import java.util.HashMap;
//import java.util.Map;
//import java.util.Set;
//
//class RandomListNode {
//    int label;
//   RandomListNode next, random;
//   RandomListNode(int x) { this.label = x; }
//}
//////this is clever way
////class Solution{
////	public static RandomListNode copyRandomList(RandomListNode  head) {
////		 if (head == null) return null;
////		 RandomListNode cur = head;
////	        while (cur!=null) {
////	            RandomListNode node = new RandomListNode(cur.label);//only in this way
////	            node.next = cur.next;
////	            cur.next = node;
////	            cur = node.next;
////	        }
////	        cur = head;
////	        while (cur!=null) {
////	            if (cur.random!=null) {
////	                cur.next.random = cur.random.next;
////	            }
////	            cur = cur.next.next;
////	        }
////	        cur = head;
////	        RandomListNode res = head.next;
////	        while (cur!=null) {
////	            RandomListNode tmp = cur.next;
////	            cur.next = tmp.next;
////	            if(tmp.next!=null) 
////	            	tmp.next = tmp.next.next;
////	            cur = cur.next;
////	        }
////	        return res;
////		}
////}
////my
//class Solution {
//    public RandomListNode copyRandomList(RandomListNode head) {
//        if(head==null)
//            return null;
//        RandomListNode cur=head;
//        while(cur!=null){
//            RandomListNode tt=new RandomListNode(cur.label);
//            tt.next=cur.next;
//            cur.next=tt;
//            cur=tt.next;
//        }
//        cur=head;
//        RandomListNode ans;
//        while(cur!=null){
//            if(cur.random!=null){
//                cur.next.random=cur.random.next;//***********
//            }
//            cur=cur.next.next;
//        }
//        
//        cur=head;
//        RandomListNode res=head.next;
//        while(cur!=null){  
//        	ans=cur.next;
//            cur.next=ans.next;
//            if(ans.next!=null){
//                ans.next=cur.next.next;
//            }
//            cur=cur.next;
//        }
//        return res;
//    }
//}
//
//
////
//////this is traditional way--- hash map:
//////the data in map is single new node:
////class Solution{
////	public static RandomListNode copyRandomList(RandomListNode  head) {
////		if (head == null) return null;
////        RandomListNode res = new RandomListNode(head.label);
////        RandomListNode node = res;
////        RandomListNode cur = head.next;
////        
////        Map<RandomListNode, RandomListNode> m=new HashMap<RandomListNode, RandomListNode>();
////        m.put(head, res);
////        while (cur!=null) {
////            RandomListNode tmp = new RandomListNode(cur.label);
////            node.next = tmp;
////            m.put(cur, tmp);//m[cur] = tmp;
////            node = node.next;
////            cur = cur.next;
////        }
////        node = res;
////        cur = head;
////        while (node!=null) {
////            node.random = m.get(cur.random);//  m[cur->random];
////            node = node.next;
////            cur = cur.next;
////        }
////        return res;
////		}
////}
//public class lc138 {
//	  
//public static void main(String arg[]) {
//	RandomListNode aa= new RandomListNode(12);
//	//Solution.copyRandomList(aa);
//	System.out.println("Hello world");
//}
//}
