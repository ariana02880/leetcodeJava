//import java.util.HashMap;
//
//import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;
//
//import com.sun.javafx.image.IntPixelAccessor;
//
// // Definition for singly-linked list.
//class ListNode {
//      int val;
//      ListNode next;
//     ListNode(int x) { val = x; }
//}
//
// //Definition for a binary tree node.
//class TreeNode {
//     int val;
//     TreeNode left;
//     TreeNode right;
//     TreeNode(int x) { val = x; }
// }
//
////my �߽� �ӿ�ʼ ��β��ʼ
//class Solution {
//	public int trap(int[] height) {
//        int n=height.length;
//        int idx=0;
//        for(int i=0;i<n;i++) {
//        	idx= height[i]>=height[idx]? i:idx;
//        }
//        //left
//        int area=0,left=0;
//        for(int i=0;i<idx;i++) {
//        	if(left>height[i] )
//        		area+=left-height[i];
//        	else
//        		left=height[i];
//        }
//        //right
//        int right=0;
//        for(int i=n-1;i>idx;i--) {
//        	if(right>height[i])
//        		area+=right-height[i];
//        	else
//        		right=height[i];
//        }
//        return area;
//    }
//}
//
//
//public class lc42 {
//public static void main(String arg[]) {
//		Solution test=new Solution();
//		
//		int[] digits=new int[] {2,0,2};
//		int a=test.trap(digits);
//		System.out.println("Hello World");
//
//	}
//}
